/*
 * @(#) MetalClassViewerNavigatorUI.java 1.12 - last change made 01/29/99
 *
 * (c) 1997-1998 Sun Microsystems, Inc.  All rights reserved.  Use is
 * subject to license terms. Sun, Sun Microsystems, the Sun Logo, Solaris,
 * Java, the Java Coffee Cup Logo, and JavaHelp are trademarks or registered
 * trademarks of Sun Microsystems, Inc. in  the U.S. and other countries.
 */

package sunw.demo.classviewer.plaf.metal;

import sunw.demo.classviewer.plaf.basic.*;
import sunw.demo.classviewer.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.*;
import javax.help.*;

/**
 * The organic UI for a ClassViewerNavigator
 *
 * @author Eduardo Pelegri-Llopart
 * @version	1.12	01/29/99
 */

public class MetalClassViewerNavigatorUI extends BasicClassViewerNavigatorUI {
    public static ComponentUI createUI(JComponent x) {
        return new MetalClassViewerNavigatorUI((ClassViewerNavigator) x);
    }

    public MetalClassViewerNavigatorUI(ClassViewerNavigator x) {
	super(x);
    }
}
