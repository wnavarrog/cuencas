/*
 * @(#) ClassViewerView.java 1.4 - last change made 01/29/99
 *
 * (c) 1997-1998 Sun Microsystems, Inc.  All rights reserved.  Use is
 * subject to license terms. Sun, Sun Microsystems, the Sun Logo, Solaris,
 * Java, the Java Coffee Cup Logo, and JavaHelp are trademarks or registered
 * trademarks of Sun Microsystems, Inc. in  the U.S. and other countries.
 */

package sunw.demo.classviewer;

import java.awt.Component;
import java.util.Hashtable;
import java.util.Locale;
import javax.help.HelpSet;
import javax.help.HelpModel;
import javax.help.NavigatorView;

/**
 * View information for a ClassViewer Navigator
 *
 * @author Eduardo Pelegri-Llopart
 * @version	1.4	01/29/99
 */

public class ClassViewerView extends NavigatorView {
    /**
     * Construct a ClassViewer VIew with some given data.  Locale defaults
     * to that of the HelpSet
     *
     * @param hs The HelpSet that provides context information
     * @param name The name of the View
     * @param label The label (to show the user) of the View
    * @param params A Hashtable providing different key/values for this type
    */
    public ClassViewerView(HelpSet hs,
			   String name,
			   String label,
			   Hashtable params) {
	super(hs, name, label, hs.getLocale(), params);
    }

    /**
     * Construct a ClassViewer VIew with some given data.
     *
     * @param hs The HelpSet that provides context information
     * @param name The name of the View
     * @param label The label (to show the user) of the View
     * @param locale The default locale to interpret data in this View
    * @param params A Hashtable providing different key/values for this type
    */
    public ClassViewerView(HelpSet hs,
			   String name,
			   String label,
			   Locale locale,
			   Hashtable params) {
	super(hs, name, label, locale, params);
    }

    /**
     * create a navigator for a given model
     */
    public Component createNavigator(HelpModel model) {
	return new ClassViewerNavigator(this, model);
    }
}
