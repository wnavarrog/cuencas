/*
 * @(#) MotifClassViewerNavigatorUI.java 1.10 - last change made 01/29/99
 *
 * (c) 1997-1998 Sun Microsystems, Inc.  All rights reserved.  Use is
 * subject to license terms. Sun, Sun Microsystems, the Sun Logo, Solaris,
 * Java, the Java Coffee Cup Logo, and JavaHelp are trademarks or registered
 * trademarks of Sun Microsystems, Inc. in  the U.S. and other countries.
 */

package sunw.demo.classviewer.plaf.motif;

import sunw.demo.classviewer.plaf.basic.*;
import sunw.demo.classviewer.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.*;
import javax.help.*;

/**
 * The motif UI for a ClassViewerNavigator
 *
 * @author Eduardo Pelegri-Llopart
 * @version	1.10	01/29/99
 */

public class MotifClassViewerNavigatorUI extends BasicClassViewerNavigatorUI {
    public static ComponentUI createUI(JComponent x) {
        return new MotifClassViewerNavigatorUI((ClassViewerNavigator) x);
    }

    public MotifClassViewerNavigatorUI(ClassViewerNavigator x) {
	super(x);
    }
}
