package sunw.demo.browser;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.util.Locale;
import java.io.IOException;
import javax.help.*;

/** 1.2 version of this
 */

public class HelpButton extends JApplet implements ActionListener{
    private String helpSetName = null;
    private String helpSetURL = null;
    private HelpSet hs;
    private HelpBroker hb;
    private JButton button;
    static JFrame frame;

    public HelpButton() {
	super();
    }

    public HelpButton(String hsName, String hsURL) {
	helpSetName = hsName;
	helpSetURL = hsURL;
	button = new JButton("Help");
	button.addActionListener(this);
	this.getContentPane().add(button);
    }

    public void init() {
	helpSetName = getParameter("HELPSETNAME");
	helpSetURL = getParameter("HELPSETURL");
	button = new JButton("Help");
	button.addActionListener(this);
	this.getContentPane().add(button);
    }


    public void stop() {
        if (button != null) {
            getContentPane().remove(button);
            button = null;
        }
	hs = null;
	hb = null;
    }

    public void actionPerformed(ActionEvent e){
	if (hs == null) {
	    createHelpSet();
	    hb = hs.createHelpBroker();
	}
	hb.setDisplayed(true);
    }

    private void createHelpSet() {
	ClassLoader loader = this.getClass().getClassLoader();
	URL url;
	try {
	    url = HelpSet.findHelpSet(loader, helpSetName);
	    debug ("findHelpSet url=" + url);
	    if (url == null) {
		url = new URL(getCodeBase(), helpSetURL);
		debug("codeBase url=" + url);
	    }
	    hs = new HelpSet(loader, url);
	} catch (Exception ee) {
	    System.out.println ("Trouble in createHelpSet;");
	    ee.printStackTrace();
	    return;
	}
    }

    public static void main(String args[]) throws Exception {
	frame=new JFrame("HelpButton demo");
	frame.getContentPane().setLayout(new BorderLayout());
	frame.getContentPane().add(new HelpButton("HolidayHistory", 
						  "HolidayHistory.hs"),
				   "Center");
	frame.show();
    }

    /**
     * For printf debugging.
     */
    private final boolean debug = false;
    private void debug(String str) {
        if (debug) {
            System.out.println("HelpButton: " + str);
        }
    }

}
